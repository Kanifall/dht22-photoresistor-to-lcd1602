#include <Wire.h>
#include <LiquidCrystal_I2C.h>
#include <DHT.h>
#define DHTPIN 7
#define ModeDel 1500
#define FirstMenuDel 1500
#define DelPh 2000
#define DelPh2 2500
#define PIN_LED 13
#define PIN_PHOTO_SENSOR A0

int val = analogRead(PIN_PHOTO_SENSOR);

DHT dht(DHTPIN, DHT22);
LiquidCrystal_I2C lcd(0x27, 16, 2);

byte Smile2[8] = {
  0b00000,
  0b10010,
  0b10010,
  0b00000,
  0b00001,
  0b00010,
  0b00100,
  0b11000
};
byte Smile3[8] = {
  B00000,
  B10001,
  B10001,
  B00000,
  B00000,
  B00001,
  B10010,
  B01100
};
byte Smile[8] = {
  0b00010,
  0b00001,
  0b11001,
  0b00001,
  0b11001,
  0b00001,
  0b00010,
  0b00000
};
byte Gradus[8] = {
  B00110,
  B01001,
  B01001,
  B00110,
  B00000,
  B00000,
  B00000,
  B00000
};

void VeryBright()
{
  lcd.clear(); // очистка :D
  lcd.setCursor(0, 0); // курсор вначало :>
  lcd.print("It's very"); // very светло
  lcd.setCursor(0, 1); // вторая строчка :>
  lcd.print("bright now"); // в комнате :)
  lcd.print(char(Smile2)); // эмодзик
  // It's very bright now
}
void Light()
{
  lcd.clear(); // очистка :D
  lcd.setCursor(0, 0); // курсор вначало :>
  lcd.print("..It's light"); // светло
  lcd.setCursor(0, 1); // вторая строчка :>
  lcd.print("the room now"); // в комнате :)
  lcd.print(char(Smile)); // эмодзик
  //..It's light the room now
}
void Dark()
{
  lcd.clear(); // очистка :D
  lcd.setCursor(0, 0); // курсор вначало :>
  lcd.print("It's too dark!"); // темно
  lcd.setCursor(0, 1); // вторая строчка :>
  lcd.print("I can't see any "); // в комнате :)
  lcd.print(char(Smile3)); // эмодзик
  //It's too dark! I can't see any
}
void value()
{
  int val = analogRead(PIN_PHOTO_SENSOR);
  Serial.print("Photoresistor value:");
  Serial.println(val);
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("value of light");
  lcd.setCursor(0, 1);
  lcd.print("photores = ");
  lcd.print(val);
  //PhotoResist Information
}

void PhotoResInfo()
{
  int val = analogRead(PIN_PHOTO_SENSOR);
  Serial.print("Photoresistor value: ");
  Serial.println(val);
  value();
}
void PhotoRes() {
  int val = analogRead(PIN_PHOTO_SENSOR);
  Serial.print("Photoresistor value: ");
  Serial.println(val);
  if (val > 619)
  {
    Dark();
    delay(DelPh);
    value();
    delay(DelPh2);
    Dark();

  }
  else if (val > 250)
  {
    Light();
    delay(DelPh);
    value();
    delay(DelPh2);
    Light();
  }
  else
  {
    VeryBright();
    delay(DelPh);
    value();
    delay(DelPh2);
    VeryBright();
  }
}
void HumHud() {
  float h = dht.readHumidity();
  lcd.setCursor(0, 0);
  lcd.print("air humidity");
  lcd.setCursor(0, 1);
  lcd.print("is now ");
  lcd.print(h);
  lcd.print("%");
}
void TempHud() {
  float t = dht.readTemperature();
  lcd.setCursor(0, 0);
  lcd.print("it's ");
  lcd.print(t);
  lcd.print(char(223));
  lcd.setCursor(0, 1);
  lcd.print("degrees side");
}
void setup() {
  Serial.begin(9600);
  pinMode(PIN_LED, OUTPUT);
  lcd.init();
  lcd.backlight();
  dht.begin();
  lcd.begin(16, 2);
  lcd.createChar(0, Gradus);
  lcd.createChar(1, Smile2);
  lcd.createChar(2, Smile);
  lcd.createChar(3, Smile3);
}

void MinimalisticMenu()
{
  float h = dht.readHumidity();
  float t = dht.readTemperature();
  int p = analogRead(PIN_PHOTO_SENSOR);
  lcd.createChar(0, Gradus);
  lcd.setCursor(0, 0);
  lcd.print("Temperature");
  lcd.setCursor(5, 1);
  lcd.print(t);
  lcd.write(0);
  lcd.print(" ");
  lcd.write(2);
  delay(3500);
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("Humidity");
  lcd.setCursor(5, 1);
  lcd.print(h);
  lcd.print("% ");
  lcd.write(1);
  delay(3500);
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("Photoresistor");
  lcd.setCursor(5, 1);
  lcd.print(p);
  lcd.print(" Om ");
  lcd.write(3);
  delay(4000);
  lcd.clear();
}

// void AllWriteMenu()
// {
//   float h = dht.readHumidity();
//   float t = dht.readTemperature();
//   int p = analogRead(PIN_PHOTO_SENSOR);
//   lcd.setCursor(0, 0);
//   lcd.print(h);
//   lcd.print("% ");
//   lcd.print(t);
//   lcd.print(char(223));
//   lcd.print(char(67));
//   lcd.setCursor(0, 1);
//   lcd.print("Photores = ");
//   lcd.print(p);
// }

// void MainMenu()
// {
//   //  Temperature mode
//   TempHud();
//   delay(4000);
//   lcd.clear();
//   // Humidity mode
//   HumHud();
//   delay(4000);
//   lcd.clear();
//   // Photoresistor mode
//   PhotoRes();
//   delay(4000);
//   lcd.clear();
// }

void loop()
{
  MinimalisticMenu();
}
